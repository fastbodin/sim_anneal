from .qubo_dense_solver import qubo_solve
